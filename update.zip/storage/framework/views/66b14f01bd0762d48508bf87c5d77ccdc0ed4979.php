<?php $__env->startSection('personalData'); ?>
 <div class="row">
  <!--Professional Info-->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Personal Informations</b>
                            <a class="pull-right" href="<?php echo e(url('examine/personalInfo/editPersonalInfos')); ?>">Edit</a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 <?php if($infos): ?>
                                    <tbody>
                                       <tr>
                                       		<th>Title</th><td><?php echo e($infos->title); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Full Name</th><td><?php echo e($infos->name); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Father Name</th><td><?php echo e($infos->father_name); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Mother Name</th><td><?php echo e($infos->mother_name); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Date Of Birth</th><td><?php echo e($infos->date_of_birth); ?></td>
                                       	</tr>
                                       	
                                       	
                                       	<tr>
                                       		<th>Nationality</th><td><?php echo e($infos->nationality); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Passport No.</th><td><?php echo e($infos->passport_no); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Passport Validity</th><td><?php echo e($infos->validity_date); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Parmanent Address</th><td><?php echo nl2br($infos->parmanent_address);?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Mailing Address</th><td><?php echo nl2br($infos->mailing_address);?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Gender</th><td><?php echo e($infos->gender); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Photo</th>
                                          <td>
                                              <?php $images=App\AdminModel::getDocuments('users', Auth::user()->id) ?>
                                            <?php if($images): ?>
                                                <?php foreach($images as $img): ?>
                                                 <img style="height: 100px" class="img-thumbnail img-responsive " src="<?php echo e(asset('public/documents/'.$img->calling_id)); ?>" alt="Examine Photo" />
                                                 <?php break;?>
                                                 <?php endforeach; ?>
                                            <?php else: ?> 
                                                No Photo 
                                            <?php endif; ?>
                                          </td>
                                       </tr>
                                       
                                    </tbody>
                                    <?php else: ?>
                                    <tbody>
                                      <tr>
                                        <td colspan="2">No Data Provided</td>
                                      </tr>
                                    </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
			
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>