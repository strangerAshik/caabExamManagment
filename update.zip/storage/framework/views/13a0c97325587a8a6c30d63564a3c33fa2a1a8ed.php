<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
<?php echo Form::open(array('url'=>'updatePaymentDetails','method'=>'post','class'=>'form-horizontal','data-toggle'=>'validator','role'=>'form','files'=>'true')); ?>

	
	<?php echo Form::hidden('id',$payment->id); ?>

	<div class="form-group">
	    <label for="exampleInputEmail1" class="col-sm-3 control-label">Fee Type</label>
	    <div class="col-sm-4">
	    <select name="fee_type" placeholder=""class="form-control">
		  <option value="">Select Fee Type..</option>
		  <option <?php if($payment->fee_type=='CASH') echo"selected=''";?>value="CASH">CASH</option>
		  <option <?php if($payment->fee_type=='DD') echo"selected=''";?> value="DD">DD</option>
		  <option <?php if($payment->fee_type=='TT') echo"selected=''";?> value="TT">TT</option>
		</select>
		</div>

	</div>
	
	
	<div class="form-group">
	    <label for="exampleInputEmail1" class="col-sm-3 control-label">Document Number</label>
	    <div class="col-sm-4">
	    <input name="doc_number" value="<?php echo e($payment->doc_number); ?>" type="text" class="form-control" id="date" placeholder=" ">
		</div>
	</div>
	<div class="form-group">
	    <label for="exampleInputEmail1" class="col-sm-3 control-label">Bank</label>
	    <div class="col-sm-4">
	    <input name="bank" value="<?php echo e($payment->bank); ?>" type="text" class="form-control" id="date" placeholder=" ">
		</div>
	</div>
	<div class="form-group">
	    <label for="exampleInputEmail1" class="col-sm-3 control-label">Branch</label>
	    <div class="col-sm-4">
	    <input name="branch" value="<?php echo e($payment->branch); ?>" type="text" class="form-control" id="date" placeholder=" ">
		</div>
	</div>
	<div class="form-group">
	    <label for="exampleInputEmail1" class="col-sm-3 control-label">Account Name</label>
	    <div class="col-sm-4">
	    <input name="account_name" value="<?php echo e($payment->account_name); ?>" type="text" class="form-control" id="date" placeholder=" ">
		</div>
	</div>
	
	<div class="form-group">
	    <label for="" class="col-sm-3 control-label">Uploaded  Document </label>
	    <div class="col-sm-4">
	     <?php $images=App\AdminModel::getDocuments('exam_payments', $payment->id) ?>
                                            <?php if($images): ?>
                                                <?php foreach($images as $img): ?>
                                                 
                                                
                                                 <a target="_blink" href="<?php echo e(asset('public/documents/'.$img->calling_id)); ?>"><?php echo e($img->doc_name); ?></a> 
                                                 <a style="color: red" onclick="return confirm('Wanna Delete?');" href="<?php echo e(url('deleteBack/documents/'.$img->id)); ?>">[Delete]</a>,
                                                 
                                                 <?php endforeach; ?>
                                            <?php else: ?> 
                                                No doc 
                                            <?php endif; ?>   
		</div>
	</div>
	<div class="form-group">
	    <label for="" class="col-sm-3 control-label">Upload  Document </label>
	    <div class="col-sm-4">
	    <input name="bank_doc[]" multiple="true" type="file" class="">
		</div>
	</div>
	

	   <div class="form-group">
	        <label class="control-label col-md-1"></label>
	        <div class="text-right col-md-8">
	            <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
	                <button type="reset" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
	                <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Apply</button>
	            </div>

	        </div>
	    </div>
<?php echo Form::close(); ?>}


	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutExamine', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>