<?php $__env->startSection('content'); ?>

   <div class="row">
                <div class="col-lg-12">
                <?php if($details): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>License Type: <?php echo e($details->licence_type); ?> | Subject: <?php echo e($details->subject); ?> | Chapter: <?php echo e($details->chapter); ?></b>
                            <span class='pull-right'>

                        
                            <a class="label label-primary" href="<?php echo e(url('questionBank/editQuestion/'.$details->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Edit</a> 

                            |

                            <a class="label label-danger" href="<?php echo e(url('deleteBack/question_bank/'.$details->id)); ?>" onclick=" return confirm('Wanna Delete?')"><span class="glyphicon glyphicon-trash"></span> Delete</a>

                            </span>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper table-responsive">
                                <table class="table  table-bordered table-hover" id="">
                                   
                                    <tbody>
                                        <tr >
                                               <th class="col-md-3">Question</th>
                                               <td><?php echo e($details->question); ?> </td>                     
                                        </tr>
                                        <tr >
                                               <th>Option-1</th>
                                               <td><?php echo e($details->option_1); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Option-2</th>
                                                <td><?php echo e($details->option_2); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Option-3</th>
                                                <td><?php echo e($details->option_3); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Option-4</th>
                                                <td><?php echo e($details->option_4); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Correct Answer</th>
                                                <td>
                                                    <?php if($details->option_right=='1'): ?>
                                                    Option-1
                                                    <?php elseif($details->option_right=='2'): ?>
                                                    Option-2
                                                    <?php elseif($details->option_right=='3'): ?>
                                                    Option-3
                                                    <?php elseif($details->option_right=='4'): ?>
                                                    Option-4
                                                    <?php else: ?>
                                                    Not Provided
                                                    <?php endif; ?>
                                                </td>                     
                                        </tr>
                                        <tr >
                                               <th>Note</th>
                                                <td><?php echo e($details->note); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Photo</th>
                                               <td>
                                               <?php if($details->image): ?>
                                               <img style="height: auto" class="img-thumbnail img-responsive" height="300" width="400" src="<?php echo e(asset('public/documents/'.$details->image)); ?>" alt="Examine Photo" />
                                               <?php else: ?>
                                                    No Photo
                                               <?php endif; ?>
                                               <div style="display: none">
                                            {{-- <?php $images=App\AdminModel::getDocuments('question_bank', $details->id) ?>
                                            <?php if($images): ?>
                                                <?php foreach($images as $img): ?>
                                                 <img style="height: auto" class="img-thumbnail img-responsive" src="<?php echo e(asset('public/documents/'.$img->calling_id)); ?>" alt="Examine Photo" />
                                                 <?php break;?>
                                                 <?php endforeach; ?>
                                            <?php else: ?> 
                                                No Photo 
                                            <?php endif; ?>
                                             --}}
                                             </div>

                                               </td>                     
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <?php else: ?>
                    Question Does not exist....
                    <?php endif; ?>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdminTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>