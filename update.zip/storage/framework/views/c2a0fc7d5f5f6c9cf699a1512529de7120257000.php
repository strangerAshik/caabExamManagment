<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
	
	<?php echo Form::open(array('url'=>'questionBank/updateQuestion','method'=>'post','class'=>'form-horizontal','data-toggle'=>'validator','role'=>'form','files'=>'true')); ?>

                     <?php echo csrf_field(); ?>

       <?php echo Form::hidden('id',$question->id); ?>

	  <div class="form-group">
	   
	    <label for="Licence" class="col-sm-2 control-label">Licence Type</label>
	    <div class="col-sm-2">
	      <select required="" name="licence_type" placeholder=""class="form-control" value="<?php echo e(old('licence_type')); ?>">
		  <option value="">Select Licence Type..</option>
		  <?php foreach($licenceTypes as $info): ?>
		  	<?php if($info->id==$question->licence_type): ?>
		  	<option selected="" value="<?php echo e($info->id); ?>"><?php echo e($info->licence_type); ?></option>
		  	<?php else: ?>
		  	<option value="<?php echo e($info->id); ?>"><?php echo e($info->licence_type); ?></option>
		  	<?php endif; ?>
		  <?php endforeach; ?>
		</select>
		<a href="#"><span class="label label-primary" data-toggle="modal" data-target="#licenceType">New Licence Type</span></a>
		

	    </div>

	    <label for="inputEmail3" class="col-sm-2 control-label">Subject</label>
	    <div class="col-sm-2">
	      <select  required="" name="subject" placeholder=""class="form-control">
		  <option value="">Select Subject..</option>
		<?php foreach($subjects as $info): ?>
			<?php if($info->id==$question->subject): ?>
		 	 <option selected="" value="<?php echo e($info->id); ?>"><?php echo e($info->subject.' ( '.$info->licence_type.' ) '); ?></option>
		  	<?php else: ?>
			  <option value="<?php echo e($info->id); ?>"><?php echo e($info->subject.' ( '.$info->licence_type.' ) '); ?></option>
		  	<?php endif; ?>
		<?php endforeach; ?>
		  
		</select>
		<a href="#"><span class="label label-primary" data-toggle="modal" data-target="#subject">New Subject</span></a>
	    </div>
	    
	    <label for="inputEmail3" class="col-sm-2 control-label">Chapter</label>
	    <div class="col-sm-2">
	      <select  required="" name="chapter" placeholder=""class="form-control">
		  <option value="">Select Chapter..</option>
		  <?php foreach($chapters as $info): ?>
		  	<?php if($info->id==$question->chapter): ?>
		  	<option selected="" value="<?php echo e($info->id); ?>" ><?php echo e($info->chapter.'( '.$info->licence_type . ' / '.$info->subject.' ) '); ?></option>
		  	<?php else: ?>
			<option value="<?php echo e($info->id); ?>" ><?php echo e($info->chapter.'( '.$info->licence_type . ' / '.$info->subject.' ) '); ?></option>
		  	<?php endif; ?>
		  <?php endforeach; ?>
		</select>
		<a href="#"><span class="label label-primary" data-toggle="modal" data-target="#chapter">New Chapter</span></a>
	    </div>
	    
	  </div>
	  

	  

	  <div class="form-group">

	    <label for="inputEmail3" class="col-sm-2 control-label">Question</label>
	    <div class="col-sm-6">
	    	<textarea  required="true" name="question"  class="form-control" rows="3" cols="5"  value="<?php echo e(old('question')); ?>"><?php echo $question->question;?></textarea>
	      
	    </div>

	    <label for="inputEmail3" class="col-sm-2 control-label">Difficulty Level</label>
	    <div class="col-sm-2">
	      <select  required="true" name="difficulty_level" placeholder=""class="form-control" value="<?php echo e(old('difficulty_level')); ?>">
		  <option value="">Select..</option>
		  <option <?php if($question->difficulty_level=='1') echo "selected=''";?> value="1">Low</option>
		  <option <?php if($question->difficulty_level=='2') echo "selected=''";?> value="2">Medium</option>
		  <option <?php if($question->difficulty_level=='3') echo "selected=''";?> value="3">High</option>
		</select>
	    </div>
	   
	  </div>

	  <div class="form-group">
		   <label for="inputEmail3" class="col-sm-2 control-label">Option-1</label>
		    <div class="col-sm-4">
		       <input required="" type="text"name="option_1" value="<?php echo e($question->option_1); ?>" class="form-control"  placeholder=" ">
		    </div>

		   <label for="inputEmail3" class="col-sm-2 control-label">Option-2</label>
		    <div class="col-sm-4">
		       <input required="" type="text"name="option_2" value="<?php echo e($question->option_2); ?>" class="form-control"  placeholder=" ">
		    </div>
	  </div>

	  <div class="form-group">
		   <label for="inputEmail3" class="col-sm-2 control-label">Option-3</label>
		    <div class="col-sm-4">
		       <input required="" type="text" name="option_3" value="<?php echo e($question->option_3); ?>" class="form-control"  placeholder=" ">
		    </div>

		   <label for="inputEmail3" class="col-sm-2 control-label">Option-4</label>
		    <div class="col-sm-4">
		       <input required="" type="text"name="option_4" value="<?php echo e($question->option_4); ?>" class="form-control"  placeholder=" ">
		    </div>
	  </div>

	  <div class="form-group">
		   <label for="inputEmail3" class="col-sm-2 control-label">Right Answer</label>
		    <div class="col-sm-4">
		       <select required="" name="option_right" placeholder=""class="form-control">
				  <option value="">Select Answer..</option>
				  <option <?php if($question->option_right=='1') echo "selected=''";?> value="1">Option-1</option>
				  <option <?php if($question->option_right=='2') echo "selected=''";?> value="2">Option-2</option>
				  <option <?php if($question->option_right=='3') echo "selected=''";?> value="3">Option-3</option>
				  <option <?php if($question->option_right=='4') echo "selected=''";?> value="4">Option-4</option>
				</select>
		    </div>
		  

		   
	  </div>
	  



	  <div class="form-group">
	  <label for="inputEmail3" class="col-sm-2 control-label">Existing Image</label>
		    <div class="col-sm-4">
		       <?php $images=App\AdminModel::getDocuments('question_bank', $question->id) ?>
                                            <?php if($images): ?>
                                                <?php foreach($images as $img): ?>
                                                 <img style="height: 100px" class="img-thumbnail img-responsive" src="<?php echo e(asset('public/documents/'.$img->calling_id)); ?>" alt="Examine Photo" />
                                                 <?php break;?>
                                                 <?php endforeach; ?>
                                                 <a onclick="return confirm('Wanna Delete?')" href="<?php echo e(url('deleteBack/documents/'.$img->id)); ?>">Delete</a>
                                            <?php else: ?> 
                                                No Photo 
                                            <?php endif; ?>
		    </div>
	  <label for="inputEmail3" class="col-sm-2 control-label">Image</label>
		    <div class="col-sm-4">
		       <img id="blah"  width="100" height="100" />
                   <input  type="file" name="photo[]" multiple="true" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
		    </div>
	  </div>

	  <div class="form-group">
	  <label for="inputEmail3" class="col-sm-2 control-label">Note</label>
		    <div class="col-sm-10">
		 <textarea name="note" class="form-control" rows="3"><?php echo $question->note ;?></textarea>
		    </div>
	    
	   
	  </div>
	
	  
	   <div class="form-group">
	        <label class="control-label col-md-4"></label>
	        <div class="text-right col-md-8">
	            <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
	                <button type="reset" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
	                <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Updte Question</button>
	            </div>

	        </div>
	    </div>
	</form>
</div>
</div>

<?php echo $__env->make('core.admin.questionBank.entryForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('licenceType'); ?>
<?php echo $__env->yieldContent('subject'); ?>
<?php echo $__env->yieldContent('chapter'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>