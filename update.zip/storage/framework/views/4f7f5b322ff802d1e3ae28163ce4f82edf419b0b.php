<?php $__env->startSection('professionalData'); ?>
<div class="row">
 			<!--Professional Info-->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Professional Informations</b>
                            <?php if(!$infos): ?>
                            <a class="pull-right" href="<?php echo e(url('examine/personalInfo/addProfessional')); ?>">Add</a>
                            <?php else: ?>
                            <a  class="pull-right" href="<?php echo e(url('examine/personalInfo/editProfessional')); ?>">Update</a>
                            <?php endif; ?>
                        </div>
                        <!-- /.panel-heading -->
                        
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 <?php if($infos): ?>
                                    <tbody>
                                    
                                       	<tr>
                                       		<th class="col-md-4">Date of First training Flight</th><td><?php echo e($infos->first_training_date); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Defense Personnel</th><td><?php echo e($infos->defense_personnel); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Defense Category</th><td><?php echo e($infos->defence_category); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Whether Having SPL or Not</th><td><?php echo e($infos->having_spl_or_not); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Date of issue of SPL</th><td><?php echo e($infos->date_of_issue_of_spl); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Whether Having Higher Category Pilot License?</th><td><?php echo e($infos->higher_category_pilot_license); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>License Category</th><td><?php echo e($infos->license_category); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>License Number</th><td><?php echo e($infos->license_number); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>License Validity</th><td><?php echo e($infos->license_validity); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Endorsement of Multi Engine Aircraft</th><td><?php echo e($infos->endorsement_of_multi_engine_aircraft); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Total Flying Hour</th><td><?php echo e($infos->total_flying_hour); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Total Flying Hour as Pilot in Command</th><td><?php echo e($infos->total_flying_hour_as_pilot_in_command); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Flying Training Institute</th><td><?php echo e($infos->flying_training_institute); ?></td>
                                       </tr>
                                        <tr>
                                          <th>Ground Training Institute</th><td><?php echo e($infos->ground_training_institute); ?></td>
                                       </tr>
                                       	<tr>
                                       		<th>Document(s)</th><td>
                                                <?php $images=App\AdminModel::getDocuments('professional_details', $infos->id) ?>
                                        <?php if($images): ?>
                                        <ul>
                                            <?php foreach($images as $img): ?>
                                            <li>
                                             <a target="_blink" href="<?php echo e(asset('public/documents/'.$img->calling_id)); ?>" alt="Examine Photo" ><?php echo e($img->doc_name); ?></a>
                                              <a  style="color: red" onclick="return confirm('Wanna Delete?');" href="<?php echo e(url('deleteBack/documents/'.$img->id)); ?>">[Delete]</a>
                                              </li>
                                            
                                             <?php endforeach; ?>
                                             </ul>
                                        <?php else: ?> 
                                            No Document 
                                        <?php endif; ?>
                                          </td>
                                       </tr>
                                       
                                    </tbody>
                                    <?php else: ?>
                                     <tbody>
                                       <tr>
                                         <td colspan="2">No Information Provided Yet!!</td>
                                       </tr>
                                     </tbody>
                                    <?php endif; ?>
                                </table> 
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
</div>
<!-- /.row -->


<?php $__env->stopSection(); ?>