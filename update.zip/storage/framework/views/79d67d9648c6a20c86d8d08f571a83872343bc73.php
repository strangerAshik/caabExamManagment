<?php $__env->startSection('licenceTypeEdit'); ?>
<?php foreach($licenceTypes as $info): ?>
<div class="modal fade" id="licenceTypeEdit<?php echo e($info->id); ?>" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update Licence Type</h4>
        </div>
        <div class="modal-body">
          
          <?php echo Form::open(array('url'=>'updateLicenceType','method'=>'post','class'=>'form-horizontal','data-toggle'=>'validator','role'=>'form','files'=>'true')); ?>

          <?php echo csrf_field(); ?>

          <?php echo Form::hidden('id',$info->id); ?>

			<div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Licence Type</label>
			    <div class="col-sm-9">
			       <input required="" type="text" name="licence_type" value="<?php echo e($info->licence_type); ?>" class="form-control"  placeholder=" ">
			    </div>
		    </div>

		   <div class="form-group">
		        <label class="control-label col-md-4"></label>
		        <div class="text-right col-md-8">
		            <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
		                <button type="reset" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
		                <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Save</button>
		            </div>

		        </div>
		    </div>

          <?php echo Form::close(); ?>

        </div>
        
      </div>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectEdit'); ?>
<?php foreach($subjects as $info): ?>
<div class="modal fade" id="subjectEdit<?php echo e($info->id); ?>" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update Subject</h4>
        </div>
        <div class="modal-body">
          <?php echo Form::open(array('url'=>'updateSubject','method'=>'post','class'=>'form-horizontal','data-toggle'=>'validator','role'=>'form','files'=>'true')); ?>

          <?php echo csrf_field(); ?>

          <?php echo Form::hidden('id',$info->id); ?>

				
			<div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Licence Type</label>
			    <div class="col-sm-9">
			     <select required="" name="licence_type_id" placeholder=""class="form-control">
				  <option value="">Select Licence type.....</option>
				  
				  <?php foreach($licenceTypes as $lice): ?>
				   	<?php if($info->licence_type_id==$lice->id): ?>
				 	 <option selected="" value="<?php echo e($lice->id); ?>"><?php echo e($lice->licence_type); ?></option>
				 	<?php else: ?>
					 <option value="<?php echo e($lice->id); ?>"><?php echo e($lice->licence_type); ?></option>
				 	<?php endif; ?>
				  <?php endforeach; ?>
				</select>
			    </div>
		    </div>
			<div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Subject</label>
			    <div class="col-sm-9">
			       <input required="" type="text" name="subject" value="<?php echo e($info->subject); ?>" class="form-control"  placeholder=" ">
			    </div>
		    </div>

		   <div class="form-group">
		        <label class="control-label col-md-4"></label>
		        <div class="text-right col-md-8">
		            <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
		                <button type="reset" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
		                <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Save</button>
		            </div>

		        </div>
		    </div>

          <?php echo Form::close(); ?>

        </div>
        
      </div>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('chapterEdit'); ?>
<?php foreach($chapters as $chap): ?>
<div class="modal fade" id="chapterEdit<?php echo e($chap->id); ?>" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Chapter</h4>
        </div>
        <div class="modal-body">
           <?php echo Form::open(array('url'=>'updateChapter','method'=>'post','class'=>'form-horizontal','data-toggle'=>'validator','role'=>'form','files'=>'true')); ?>

          <?php echo csrf_field(); ?>

          <?php echo Form::hidden('id',$chap->id); ?>

			
			<div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Licence Type</label>
			    <div class="col-sm-9">
			     <select required="" name="licence_type_id" placeholder=""class="form-control">
				  <option value="">Select Licence type......</option>
				  <?php foreach($licenceTypes as $info): ?>
				  	<?php if($info->id==$chap->licence_type_id): ?>
					 <option selected="" value="<?php echo e($info->id); ?>"><?php echo e($info->licence_type); ?></option>
				  	<?php else: ?>
				  	 <option value="<?php echo e($info->id); ?>"><?php echo e($info->licence_type); ?></option>
				  	<?php endif; ?>
				  <?php endforeach; ?>
				</select>
			    </div>
		    </div>
			<div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Subject</label>
			    <div class="col-sm-9">
			     <select required="" name="subject_id" placeholder=""class="form-control">
				  <option value="">Select Subject ......</option>
				  <?php foreach($subjects as $info): ?>
					  
					<?php if($info->id==$chap->subject_id): ?>
					 <option selected="" value="<?php echo e($info->id); ?>"><?php echo e($info->subject.' ( '.$info->licence_type.' ) '); ?></option>
				  	<?php else: ?>
				  	 <option value="<?php echo e($info->id); ?>"><?php echo e($info->subject.' ( '.$info->licence_type.' ) '); ?></option>
				  	<?php endif; ?>
				  <?php endforeach; ?>
				</select>
			    </div>
		    </div>
			<div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Chapter</label>
			    <div class="col-sm-9">
			       <input required="" type="text" name="chapter" value="<?php echo e($chap->chapter); ?>" class="form-control"  placeholder=" ">
			    </div>
		    </div>
		    <div class="form-group">
		   		<label for="inputEmail3" class="col-md-3 control-label">Question Numebr</label>
			    <div class="col-sm-9">
			       <input type="number" value="<?php echo e($chap->question_number); ?>" name="question_number" class="form-control"  placeholder=" ">
			    </div>
		    </div>


		   <div class="form-group">
		        <label class="control-label col-md-4"></label>
		        <div class="text-right col-md-8">
		            <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
		                <button type="reset" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
		                <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Save</button>
		            </div>

		        </div>
		    </div>

          <?php echo Form::close(); ?>

        </div>
       
      </div>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>