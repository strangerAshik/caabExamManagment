<?php $__env->startSection('content'); ?>
 <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Personal Informations</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 
                                    <tbody>
                                       <tr>
                                       		<th>Title</th><td>Title</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Full Name</th><td>Full Name</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Father Name</th><td>Father Name</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Mother Name</th><td>Mother Name</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Date Of Birth</th><td>01 January 1980</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Email</th><td>example@gmail.com</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Email</th><td>example@gmail.com</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Nationality</th><td>Bangladeshi</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Passport No.</th><td>03958329058</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Passport Validity</th><td>1/01/2019</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Parmanent Address</th><td><?php echo e(nl2br('str')); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Mailing Address</th><td><?php echo e(nl2br('str')); ?></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Gender</th><td>Male</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Photo</th><td><img src="" alt="Photo Missing"></td>
                                       </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
			<!--Academic Info-->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Academic Informations</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                	<thead>
                                		<tr>
                                			<td>Academic Degree</td>
                                			<td>Institute</td>
                                			<td>Subjects</td>
                                			<td>Result</td>
                                		</tr>
                                	</thead>
                                 
                                    <tbody>
                                       <tr>
	                                       	<td>Academic Degree</td>
											<td>Institute</td>
											<td>Subjects</td>
	                                      	<td>Result</td>
                                       </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
			<!--Professional Info-->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Academic Informations</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 
                                    <tbody>
                                    
                                       	<tr>
                                       		<th>Date of First training Flight</th><td>01 January 2013</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Defense Personnel</th><td>No</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Defense Category</th><td>Army/Navy/Airforce</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Whether Having SPL or Not</th><td>Yes</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Date of issue of SPL</th><td>Yes</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Whether Having Higher Category Pilot License?</th><td>Yes</td>
                                       	</tr>
                                       	<tr>
                                       		<th>License Category</th><td>PPL</td>
                                       	</tr>
                                       	<tr>
                                       		<th>License Number</th><td>03958329058</td>
                                       	</tr>
                                       	<tr>
                                       		<th>License Validity</th><td>1/01/2019</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Endorsement of Multi Engine Aircraft</th><td></td>
                                       	</tr>
                                       	<tr>
                                       		<th>Total Flying Hour</th><td>2000</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Total Flying Hour as Pilot in Command</th><td>200</td>
                                       	</tr>
                                       	<tr>
                                       		<th>Flying Training Institute</th><td>Institute Name</td>
                                       </tr>
                                       	<tr>
                                       		<th>Ground Training Institute</th><td>Institute Name</td>
                                       </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutExamine', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>