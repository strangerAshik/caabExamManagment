<?php $__env->startSection('content'); ?>

   <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Single Content</b>
                        <div  class="pull-right">
                            <a href="<?php echo e(url('frontManagement/editSingleContent/'.$contents->id)); ?>">Edit</a> | 
                            <a  href="<?php echo e(url('deleteBack/contents/'.$contents->id)); ?>">Delete</a>
                        </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="">
                                    
                                   <tbody>
                        <tr>
                            <th>Title</th>
                            <td><?php echo e($contents->title); ?></td>
                        </tr>
                        <?php if($contents->subtitle): ?>
                        <tr>
                            <th>Subtitle</th>
                            <td><?php echo e($contents->subtitle); ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <th>Category</th>
                            <td><?php echo e($contents->category); ?></td>
                        </tr>
                        <?php if($contents->unique_key): ?>
                        <tr>
                            <th>Unique Key</th>
                            <td><?php echo e($contents->unique_key); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($contents->content): ?>
                        <tr>
                            <th>Content</th>
                            <td><?php echo $contents->content;?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($contents->more_content): ?>
                        <tr>
                            <th>More Content</th>
                            <td><?php echo $contents->more_content;?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($contents->hyper_link): ?>
                        <tr>
                            <th>Hyper Link</th>
                            <td><?php echo e($contents->hyper_link); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($images): ?>
                        <tr>
                            <th>Images</th>
                            <td>
                                <?php foreach($images as $image): ?>
                                    <span><img class="img-thumbnail" height="200" width="200"src="<?php echo e(asset('public/uploads/'.$image->calling_id)); ?>"></span>
                                <?php endforeach; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if($pdfs): ?>
                        <tr>
                            <th>PDFs</th>
                            <td>
                                <?php foreach($pdfs as $pdf): ?>
                                    <span><a href="<?php echo e(asset('public/uploads/'.$pdf->calling_id)); ?>"><?php echo e($pdf->doc_name); ?></a></span>,
                                <?php endforeach; ?>
                            </td>
                        </tr>
                        <?php endif; ?>                      
                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdminTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>