<?php $__env->startSection('slider'); ?>
     	<!-- Slider Carousel
        ================================================== -->
        <style type="text/css">
        .slides li a img{
          height: 350px!important;
        }
        </style>
        <div class="span8">
            <div class="flexslider">
              <ul class="slides">
              <?php foreach($slider as $img): ?>
                <li><a href="#"><img  src="<?php echo e(asset('public/uploads/'.$img->calling_id)); ?>" alt="slider" /></a></li>
              <?php endforeach; ?>
               
              </ul>
            </div>
        </div>
<?php $__env->stopSection(); ?>