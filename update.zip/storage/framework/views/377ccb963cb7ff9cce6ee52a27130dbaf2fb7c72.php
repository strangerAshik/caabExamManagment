<?php $__env->startSection('content'); ?>



<!--Question -->


<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Exam Title: <?php echo e($examTime->title); ?> | License Type: <?php echo e($examTime->lictype); ?> | Subject: <?php echo e($examTime->sub); ?></b>
							<?php if($start==1): ?>
                            <span class="pull-right" style="margin-bottom:  30px">	
                            	<a  onclick="return confirm('After Submitting you won\'t able to get back Exam. Still Do you want to submit?')"  href="<?php echo e(url('examRoom/result/'.$examId)); ?>" class="btn btn-info " >Submit & View Result</a>
                            	
                            </span>
                            <?php endif; ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        <?php if($start==1): ?>
                        <?php $num=0;?>
                       <?php foreach($questions as $info): ?>
                       <form action="#" >
                        <?php echo csrf_field(); ?>

                        <?php echo Form::hidden('exam_id',$info->exam_id,array('id'=>'exam_id')); ?>

                        <div class="col-md-12">
                         <?php $ans=App\ExaminerModel::previousResult(Auth::user()->id,$info->exam_id,$info->question_id) ;?>
                        
	                        <label><?php echo e(++$num); ?>) <?php echo e($info->question); ?>


								
	                        </label>  
	                        <div class="col-md-offset-1">
	                        	 <div class="radio">

	                        	 <?php if($info->image): ?>
                                               <img style="max-height:250px; max-width:400px" class="img-thumbnail img-responsive" src="<?php echo e(asset('public/documents/'.$info->image)); ?>" alt="Examine Photo" />
                                 <?php endif; ?>
								  <label>
								 
								    <input type="radio" name="<?php echo e($info->question_id); ?>" id="hello" class="optionsRadio" value="1"
								     <?php if($ans==1) echo "checked='checked'";?> >
								    <?php echo e($info->option_1); ?>

								  </label>
								</div>
								
		                        <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" class="optionsRadio" value="2"
								     <?php if($ans==2) echo "checked='checked'";?> >
								     <?php echo e($info->option_2); ?>

								  </label>
								</div>
		                        <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" class="optionsRadio" value="3" 
								     <?php if($ans==3) echo "checked='checked'";?>>
								    <?php echo e($info->option_3); ?>

								  </label>
								</div>
								 <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" class="optionsRadio"  value="4"
								     <?php if($ans==4) echo "checked='checked'";?> >
								    <?php echo e($info->option_4); ?>

								  </label>
								</div>
	                        </div>
                        </div>
                        </form>
                       <?php endforeach; ?>
                       <?php else: ?>
						Exam Time is Not Started yet!!
                       <?php endif; ?>

	                       

	                       
                        </div>
		
	</div>
</div>
<!--#################################Clock####################-->	

		<!--<div class="button-holder">
			<a class="alarm-button"></a>
		</div>-->

		<!-- The dialog is hidden with css -->
		<div class="overlay">

			<div id="alarm-dialog">

				<h2>Exam Will Start At 10:00AM</h2>

				

			</div>

		</div>

		<div class="overlay">

			<div id="time-is-up">

				<h2>Time's up!</h2>

				<div class="button-holder">
					<a  target="_blank" href="<?php echo e(url('examRoom/result/'.$examId)); ?>" class="button blue">View Result</a>
				</div>

			</div>

		</div>
		

		
		<audio id="alarm-ring" preload>
			<source src="<?php echo e(asset('public/clock/assets/audio/ticktac.mp3')); ?>" type="audio/mpeg" />
			<source src="<?php echo e(asset('public/clock/assets/audio/ticktac.ogg')); ?>" type="audio/ogg" />
		</audio>

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutExam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>