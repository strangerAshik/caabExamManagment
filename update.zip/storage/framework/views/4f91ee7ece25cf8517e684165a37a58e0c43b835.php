<?php $__env->startSection('content'); ?>

   <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Result : Exam Title</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Full Name</th>
                                            <th>Passport No.</th>
                                            <th>Total Marks</th>
                                            <th>Obtained Marks</th>
                                            <th>Make</th>
                                            
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $num=0;?>
                                    <?php foreach($infos as $info): ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo e(++$num); ?></td>
                                            <td><?php echo e($info->name); ?></td>
                                            <td><?php echo e($info->passport_no); ?></td>
                                            <td><?php echo e($info->total_question); ?></td>
                                            <td><?php echo e($info->correct_ans); ?></td>
                                            <td>
                                            <?php $blockCheck=App\ExaminerModel::isBlock($info->id,$examId)?>
                                            <?php if($blockCheck): ?>
                                            <a class="label label-success" href="<?php echo e(url('changeBlockStatus/0/'.$info->id.'/'.$examId)); ?>">Unblock</a>
                                            <?php else: ?>
                                            <a class="label label-danger"   href="<?php echo e(url('changeBlockStatus/1/'.$info->id.'/'.$examId)); ?>">Block</a>
                                            <?php endif; ?>
                                            </td>
                                            
                                        
                                            <td class="text-center"><a href="<?php echo e(url('singleRegister/'.$info->id)); ?>"><span class="label label-success">View</span></td>
                                        </tr>
                                    <?php endforeach; ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdminTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>