<?php $__env->startSection('footer'); ?>

	<div class="footer-container"><!-- Begin Footer -->
    	
            <div class="row"><!-- Begin Sub Footer -->
                <div class="span12 footer-col footer-sub">
                    <div class="row no-margin">
                        <div class="span6"><span class="left">Copywrite © 2015 Soft Lab BD. All Right Reserved</span></div>
                        <div class="span6">
                            <span class="right">
                            <a href="<?php echo e(url('/')); ?>">Home</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('about')); ?>">About</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('contact')); ?>">Contact</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('login')); ?>">Login</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('register')); ?>">Register</a>
                            </span>
                        </div>
                    </div>
                </div>
            </div><!-- End Sub Footer -->


    </div><!-- End Footer --> 
<?php $__env->stopSection(); ?>