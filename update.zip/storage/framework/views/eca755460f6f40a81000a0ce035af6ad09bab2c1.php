<?php $__env->startSection('menue'); ?>
<div class="span4 navigation">
            <div class="navbar hidden-phone">
            
            <ul class="nav">
           <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
           <li><a href="<?php echo e(url('about')); ?>">About</a></li>
           <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
           <?php if(!Auth::check()): ?>
           <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
           <?php else: ?> 
           <li><a href="<?php echo e(url('customlogout')); ?>" style="color: red">Log Out</a></li>
           <?php endif; ?>
           <li><a href="<?php echo e(url('register')); ?>">Register</a></li>
          
            <!-- 
			//Dropdown menue
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="blog-style1.htm">Blog <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="blog-style1.htm">Blog Style 1</a></li>
                    <li><a href="blog-style2.htm">Blog Style 2</a></li>
                    <li><a href="blog-style3.htm">Blog Style 3</a></li>
                    <li><a href="blog-style4.htm">Blog Style 4</a></li>
                    <li><a href="blog-single.htm">Blog Single</a></li>
                </ul>
             </li>-->
           
            </ul>
           
            </div>

            <!-- Mobile Nav
            ================================================== -->
            <form action="#" id="mobile-nav" class="visible-phone">
                <div class="mobile-nav-select">
                <select onchange="window.open(this.options[this.selectedIndex].value,'_top')">
                    <option value="">Navigate...</option>
                    <option value="index.htm">Home</option>
                    <option value="index.htm">About</option>
                    <option value="index.htm">Contact</option>
                    <option value="index.htm">Login</option>
                    
                </select>
                </div>
                </form>

        </div>
<?php $__env->stopSection(); ?>