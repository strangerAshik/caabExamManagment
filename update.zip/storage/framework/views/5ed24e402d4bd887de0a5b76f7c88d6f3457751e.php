<?php $__env->startSection('upcomingExam'); ?>
<div class="row">
		<div class="col-md-12">

                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <b>Upcoming Exam</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
											<th>Category</th>
											<th>Subject</th>
											<th>Start Date</th>
											<th>Duration</th>
											<th>Total Sit</th>
											<th>Occupied Sit</th>
											<th>Pending Sit</th>
											<th>Note</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
										<td>1</td>
										<td>PPL</td>
										<td>Subject</td>
										<td>12-01-2016</td>
										<td class="center">2</td>
										<td class="center">20</td>
										<td class="center">2</td>
										<td class="center">5</td>
										<td> simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into </td>
									</tr>
									<tr>
										<td>2</td>
										<td>CPL</td>
										<td>Subject</td>
										<td>12-01-2016</td>
										<td class="center">2</td>
										<td class="center">20</td>
										<td class="center">2</td>
										<td class="center">5</td>
										<td class="center"> simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into </td>
									</tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
		
		</div>
		
	</div>
           

<?php $__env->stopSection(); ?>