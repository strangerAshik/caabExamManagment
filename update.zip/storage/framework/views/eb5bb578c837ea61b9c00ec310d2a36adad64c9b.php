<?php $__env->startSection('content'); ?>
<!--Question -->
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Licence Type: <?php echo e($disInfos->licence_type); ?> | Subject: <?php echo e($disInfos->subject); ?> | Chapter: <?php echo e($disInfos->chapter); ?></b> <a href="#addQuestionNew"><span style="padding: 5px;" class="pull-right label label-primary"> Add Question </span></a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        <?php $num=0;?>
                       <?php foreach($questions as $info): ?>
                        <div class="col-md-12">
	                        <label><?php echo e(++$num); ?>) <?php echo e($info->question); ?> </label> 
	                        <span style="color:green"> Subject: <?php echo e($info->subject); ?> | Chater: <?php echo e($info->chapter); ?> | DL:<?php echo e($info->difficulty_level_id); ?></span><br> 
	                        <span class="label label-danger"><a onclick="return confirm('Wanna Remove?');" href="<?php echo e(url('deleteBack/question_stors/'.$info->id)); ?>"> Remove</a></span>
	                        <div class="col-md-offset-1">
	                        	 <div class="radio">
	                        	 
	                        	  <?php if($info->image): ?>
                                               <img style="max-height:250px; max-width:400px" class="img-thumbnail img-responsive" src="<?php echo e(asset('public/documents/'.$info->image)); ?>" alt="Examine Photo" />
                                 <?php endif; ?>

								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" id="optionsRadios1" value="1" >
								    <?php echo e($info->option_1); ?>

								  </label>
								</div>
								
		                        <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" id="optionsRadios1" value="2" >
								    <?php echo e($info->option_2); ?>

								  </label>
								</div>
		                        <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" id="optionsRadios1" value="3" >
								    <?php echo e($info->option_3); ?>

								  </label>
								</div>
								 <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->question_id); ?>" id="optionsRadios1" value="4" >
								     <?php echo e($info->option_4); ?>

								  </label>
								</div>
	                        </div>
                        </div>
                       <?php endforeach; ?>
                        
	                       

	                       
                        </div>
		
	</div>
</div>
<!--Available Questions -->
<div class="row" >
	<div class="col-md-12">
		<div class="panel panel-default" id="addQuestionNew">
                        <div class="panel-heading">
                             <b>Licence Type: <?php echo e($disInfos->licence_type); ?> | Subject: <?php echo e($disInfos->subject); ?> | Chapter: <?php echo e($disInfos->chapter); ?></b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        <?php foreach($allQuestions as $info): ?>
                        <div class="col-md-12">
	                        <label><?php echo e(++$num); ?>) <?php echo e($info->question); ?> </label> 
	                        <span style="color:green"> Subject: <?php echo e($info->subject); ?> | Chater: <?php echo e($info->chapter); ?> | DL:<?php echo e($info->difficulty_level); ?></span><br> 
	                        <span class="label label-success"><a onclick="return confirm('Wanna Add?');" href='<?php echo e(url('addQuestion/'.$info->id.'/'.$questionGeneratorId.'/'.$examId)); ?>'> Add</a></span>

	                        <div class="col-md-offset-1">
	                        	<div class="radio">
	                        	 <?php if($info->image): ?>
                                               <img style="max-height:250px; max-width:400px" class="img-thumbnail img-responsive" src="<?php echo e(asset('public/documents/'.$info->image)); ?>" alt="Examine Photo" />
                                 <?php endif; ?>

								  <label>
								    <input type="radio" name="<?php echo e($info->id); ?>" id="optionsRadios1" value="1" >
								    <?php echo e($info->option_1); ?>

								  </label>
								</div>
								
		                        <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->id); ?>" id="optionsRadios1" value="2" >
								    <?php echo e($info->option_2); ?>

								  </label>
								</div>
		                        <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->id); ?>" id="optionsRadios1" value="3" >
								    <?php echo e($info->option_3); ?>

								  </label>
								</div>
								 <div class="radio">
								  <label>
								    <input type="radio" name="<?php echo e($info->id); ?>" id="optionsRadios1" value="4" >
								     <?php echo e($info->option_4); ?>

								  </label>
								</div>
	                        </div>
                        </div>
                        <?php endforeach; ?>
                       
	                       

	                       
                        </div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>