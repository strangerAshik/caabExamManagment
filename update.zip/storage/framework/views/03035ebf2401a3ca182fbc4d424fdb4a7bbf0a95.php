<?php $__env->startSection('content'); ?>

   <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Pending Registration Request</b>
                            <div class="pull-right">
                            <?php if($singleRegister): ?>
                                <?php if($singleRegister->reg_status!=1): ?>
                                <a  onclick="return confirm('Wanna Active Him?')" href="<?php echo e(url('userActive/'.$singleRegister->id)); ?>">Active</a>
                                <?php else: ?> 
                                <a href="<?php echo e(url('userInactive/'.$singleRegister->id)); ?>">Inactive</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            </div>

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="">
                                   
                                    <tbody>
                                    <?php $num=0;?>
                                        <?php if($singleRegister): ?>
                                        <tr>
                                            <th  colspan="2">
                                                <?php $images=App\AdminModel::getDocuments('users', $singleRegister->id) ?>
                                            <?php if($images): ?>
                                                <?php foreach($images as $img): ?>
                                                 <img style="height: 100px" class="img-thumbnail img-responsive pull-right" src="<?php echo e(asset('public/documents/'.$img->calling_id)); ?>" alt="Examine Photo" />
                                                 <?php break;?>
                                                 <?php endforeach; ?>
                                            <?php else: ?> 
                                                No Photo 
                                            <?php endif; ?>
                                            </th>
                                            
                                        </tr>
                                        <tr><th class="col-md-3">Title </th><td><?php echo e($singleRegister->title); ?></td></tr>
                                        <tr><th>Full Name</th><td><?php echo e($singleRegister->name); ?></td></tr>
                                        <tr><th>Father Name</th><td><?php echo e($singleRegister->father_name); ?></td></tr>
                                        <tr><th>Mother Name</th><td><?php echo e($singleRegister->mother_name); ?></td></tr>
                                        <tr><th>Date of Birth</th><td><?php echo e($singleRegister->date_of_birth); ?></td></tr>
                                        <tr><th>Email</th><td><?php echo e($singleRegister->email); ?></td></tr>
                                        <tr><th>Nationality</th><td><?php echo e($singleRegister->nationality); ?></td></tr>
                                        <tr><th>Passport No</th><td><?php echo e($singleRegister->passport_no); ?></td></tr>
                                        <tr><th>Passport Validity Date</th><td><?php echo e($singleRegister->validity_date); ?></td></tr>
                                        <tr><th>Permanent Address</th><td>
                                        <?php echo e($singleRegister->parmanent_address); ?></td></tr>
                                        <tr><th>Mailing Address</th><td>
                                        <?php echo e($singleRegister->mailing_address); ?></td></tr>
                                        <tr><th>Gender</th><td>
                                        <?php echo e($singleRegister->gender); ?></td></tr>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="2">No Data Available</td>
                                        </tr>
                                        <?php endif; ?>

                                        
                                        
                                   
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
             
            <!--Academic Info-->
            <?php if($academicInfos): ?>
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Academic Informations</b>
                          
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th> Degree</th>
                                            <th>Session</th>
                                            <th>Institute</th>
                                            <th>Subjects</th>
                                            <th>Result</th>
                                        </tr>
                                    </thead>
                                 
                                    <tbody>
                                    <?php foreach($academicInfos as $info): ?>
                                       <tr>
                                            <td><?php echo e($info->degree_name); ?></td>
                                            <td><?php echo e($info->start_date); ?> to <?php echo e($info->end_date); ?></td>
                                            <td><?php echo e($info->institute); ?></td>
                                            <td><?php echo e($info->subject); ?></td>
                                            <td><?php echo e($info->result); ?></td>
                                           
                                       </tr>
                                    <?php endforeach; ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
            <?php endif; ?>
                <!-- /.col-lg-12 -->   
            <!--Professional Info-->
            <?php if($infos): ?>
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Professional Informations</b>
                          
                        </div>
                        <!-- /.panel-heading -->
                        
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                 <?php if($infos): ?>
                                    <tbody>
                                    
                                        <tr>
                                            <th class="col-md-4">Date of First training Flight</th><td><?php echo e($infos->first_training_date); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Defense Personnel</th><td><?php echo e($infos->defense_personnel); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Defense Category</th><td><?php echo e($infos->defence_category); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Whether Having SPL or Not</th><td><?php echo e($infos->having_spl_or_not); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date of issue of SPL</th><td><?php echo e($infos->date_of_issue_of_spl); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Whether Having Higher Category Pilot License?</th><td><?php echo e($infos->higher_category_pilot_license); ?></td>
                                        </tr>
                                        <tr>
                                            <th>License Category</th><td><?php echo e($infos->license_category); ?></td>
                                        </tr>
                                        <tr>
                                            <th>License Number</th><td><?php echo e($infos->license_number); ?></td>
                                        </tr>
                                        <tr>
                                            <th>License Validity</th><td><?php echo e($infos->license_validity); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Endorsement of Multi Engine Aircraft</th><td><?php echo e($infos->endorsement_of_multi_engine_aircraft); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Total Flying Hour</th><td><?php echo e($infos->total_flying_hour); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Total Flying Hour as Pilot in Command</th><td><?php echo e($infos->total_flying_hour_as_pilot_in_command); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Flying Training Institute</th><td><?php echo e($infos->flying_training_institute); ?></td>
                                       </tr>
                                        <tr>
                                            <th>Ground Training Institute</th><td><?php echo e($infos->ground_training_institute); ?></td>
                                       </tr>
                                       
                                    </tbody>
                                    <?php else: ?>
                                     <tbody>
                                       <tr>
                                         <td colspan="2">No Information Provided Yet!!</td>
                                       </tr>
                                     </tbody>
                                    <?php endif; ?>
                                </table> 
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>  
            <?php endif; ?>
            <!--Examine Result Archive-->
            <?php if($results): ?>
            <!--Examine Result Archive-->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Result Archive</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>License Type</th>
                                            <th>Subjects</th>
                                            <th>Exam Date</th>
                                            <th>Total Mark</th>
                                            <th>Obtained Mark</th>
                                            <th>Height Mark</th>
                                        </tr>
                                    </thead>
                                 
                                    <tbody>
                                    <?php $num=0;?>
                                    <?php foreach($results as $info): ?>
                                       <tr>
                                            <td><?php echo e(++$num); ?></td>
                                            <td><?php echo e($info->licence_type); ?></td>
                                            <td><?php echo e($info->subject); ?></td>
                                            <td><?php echo e($info->exam_date); ?></td>
                                            <td><?php echo e($info->total_question); ?></td>
                                            <td><?php echo e($info->correct_ans); ?></td>
                                            <td>
                                            <?php $highestMarks=App\ExaminerModel::higestMarksofExam($info->exam_id)?>
                                            <?php echo e($highestMarks); ?>

                                            </td>
                                       </tr>
                                    <?php endforeach; ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
            <?php endif; ?>
            </div>
            <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>