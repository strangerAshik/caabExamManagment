<?php $__env->startSection('content'); ?>
			
			
 			<!--Professional Info-->
			<?php echo $__env->make('core.examine.personalInfo.personalData', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  			<?php echo $__env->yieldContent('personalData'); ?>
 			<!--Academic Data-->
			<?php echo $__env->make('core.examine.personalInfo.academicData', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldContent('academicData'); ?>
			<!--Professional Info-->
            <?php echo $__env->make('core.examine.personalInfo.professionalData', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 			<?php echo $__env->yieldContent('professionalData'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutExamine', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>