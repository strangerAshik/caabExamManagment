<?php $__env->startSection('content'); ?>

	<div class="row">
        <?php if(in_array('18', $privileges)): ?>
                <div class="col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bell fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo e($pendingReg); ?></div>
                                    <div>Pending Registration Request</div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(url('examineAdminstration/pendingReg')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
                <?php if(in_array('19', $privileges)): ?>
                <div class="col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bell fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo e($pendingExm); ?></div>
                                    <div>Pending Exam Sit Request</div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(url('examineAdminstration/pendingExm')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
    </div>
<!-- /.row -->
<?php if(in_array('17', $privileges)): ?>
<?php foreach($todayExam as $info): ?>
   <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Exam On Going Control Panel</b>
                            <a  href="<?php echo e(url('examShedule/editShedule/'.$info->id)); ?>" class="label label-primary pull-right">Schedule Management</a>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <div class="dataTable_wrapper">
                            <table class="table table-bordered table-hover">
                                <tbody>
                                    <tr><td class="col-md-2">Exam Title</td><td><?php echo e($info->title); ?></td></tr>
                                    <tr><td class="col-md-2">License Type</td><td><?php echo e($info->lic_type); ?></td></tr>
                                    <tr><td>Subject</td><td><?php echo e($info->sub); ?></td></tr>
                                    <tr><td>Date</td><td><?php echo e($info->exam_date); ?></td></tr>
                                    <tr><td>Start Time</td><td><?php echo e($info->start_time); ?></td></tr>
                                    <tr><td>End Time Time</td><td><?php echo e($info->end_time); ?></td></tr>
                                    
                                   
                                </tbody>
                            </table>
                            </div>
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Login Status</th>
                                            <th>Block/ Unblock</th>                    
                                            <th>Examinee Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $approvedExaminee=App\AdminModel::ExamExamineeList($info->id);$num=0;?>
                                    <?php foreach($approvedExaminee as $examinee): ?>
                                        <tr>
                                            <td id="<?php echo e($examinee->id); ?>"><?php echo e(++$num); ?></td>
                                            <td><?php echo e($examinee->name); ?></td>
                                            <td>
                                            <?php $loginStatus=App\AdminModel::loginStatus($examinee->id);?>
                                            <?php if($loginStatus=='0'): ?>
                                               <span class="text-success label label-success"> Logged In</span>
                                            <?php else: ?> 
                                                <span class="text-danger label label-success">Not Logged In</span>
                                            <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php $blockCheck=App\ExaminerModel::isBlock($examinee->id,$info->id)?>
                                            <?php if($blockCheck): ?>
                                            <a class="label label-success" href="<?php echo e(url('changeBlockStatus/0/'.$examinee->id.'/'.$info->id.'#'.$examinee->id)); ?>">Turn to Unblock</a>
                                            <?php else: ?>
                                            <a class="label label-danger"   href="<?php echo e(url('changeBlockStatus/1/'.$examinee->id.'/'.$info->id.'#'.$examinee->id)); ?>">Turn to Block</a>
                                            <?php endif; ?>

                                            </td>
                                           
                                            <td><a href="<?php echo e(url('singleRegister/'.$examinee->id)); ?>">View</a></td>
                                        </tr>
                                    <?php endforeach; ?>
                                  
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
<?php endforeach; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>