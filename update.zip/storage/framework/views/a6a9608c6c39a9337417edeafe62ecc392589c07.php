<?php $__env->startSection('content'); ?>

   <div class="row">
                <div class="col-lg-12">
                <?php if($details): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <b>Exam Details</b>
                        
                           <div class="pull-right">
                            <a class="label label-danger  " href="<?php echo e(url('deleteBack/exam_shedules/'.$details->id)); ?>" onclick=" return confirm('Wanna Delete?')"><span class="glyphicon glyphicon-trash"></span> Delete</a> &nbsp|&nbsp
                             <a class="label label-primary " href="<?php echo e(url('examShedule/editShedule/'.$details->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Edit </a> 
                           </div>

                            

                            </span>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper table-responsive">
                                <table class="table  table-bordered table-hover" id="">
                                   
                                    <tbody>
                                        <tr >
                                               <th class="col-md-3">Title</th>
                                               <td><?php echo e($details->title); ?> </td>                     
                                        </tr>
                                        <tr >
                                               <th>Licence Type</th>
                                               <td><?php echo e($details->licence_name); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Subject</th>
                                                <td><?php echo e($details->sub_name); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Exam Date</th>
                                                <td><?php echo e($details->exam_date); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Start Time</th>
                                                <td><?php echo e($details->start_time); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>End Time</th>
                                                <td><?php echo e($details->end_time); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Total Question</th>
                                                <td><?php echo e($details->total_question); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Total Sit</th>
                                                <td><?php echo e($details->total_sit); ?></td>                     
                                        </tr>
                                        <tr >
                                               <th>Note</th>
                                                <td><?php echo $details->note;?></td>                     
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <?php else: ?>
                    Exam Does not exist....
                    <?php endif; ?>

                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12">
                
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <b>Approved Examine List</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper table-responsive">
                                <table class="table  table-bordered table-hover" id="">
                                   <thead>
                                   <tr>
                                       <th>#</th>
                                       <th>Title</th>
                                       <th>Name</th>
                                       <th>Payment</th>
                                    </tr>
                                   </thead>
                                   <tbody>
                                   <?php $num=0;?>
                                   <?php foreach($examiners as $info): ?>
                                   <tr>
                                       <td><?php echo e(++$num); ?></td>
                                       <td><?php echo e($info->title); ?></td>
                                       <td><?php echo e($info->name); ?></td>
                                       <td><a href="<?php echo e(url('examineAdminstration/pendingExamineDetails/'.$info->user_id.'/'.$info->exam_id)); ?>">Details</a></td>
                                   </tr>
                                   <?php endforeach; ?>
                                       
                                   </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                  

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdminTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>