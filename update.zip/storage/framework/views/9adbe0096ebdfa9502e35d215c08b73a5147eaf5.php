<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-md-12">
     
        <?php echo Form::open(array('url'=>'examShedule/updateShedule/','method'=>'post','class'=>'form-horizontal','data-toggle'=>'validator','role'=>'form','files'=>'true')); ?>

          <?php echo csrf_field(); ?>

          <input type="hidden" name="id" value="<?php echo e($details->id); ?>">
         <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Title</label>
            <div class="col-sm-5">
               <input type="text" name="title" value="<?php echo e($details->title); ?>" class="form-control"  placeholder=" ">
            </div>
         </div>
         <div class="form-group">      
            <label for="exampleInputEmail1" class="col-sm-2 control-label">Licence Type</label>
            <div class="col-sm-4">
               <select placeholder="" name="licence_type" class="form-control">
                   <option value="">Select Licence Type..</option>
                    <?php foreach($licenceTypes as $info): ?>
                    <option <?php if($info->id==$details->licence_type) echo "selected=''"?> value="<?php echo e($info->id); ?>"><?php echo e($info->licence_type); ?></option>
                    <?php endforeach; ?>
               </select>
            </div>
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1" class="col-sm-2 control-label">Subject</label>
            <div class="col-sm-4">
               <select placeholder="" name="subject" class="form-control">
                   <option value="">Select Subject..</option>
                     <?php foreach($subjects as $info): ?>
                       <option <?php if($info->id==$details->subject) echo "selected=''"?> value="<?php echo e($info->id); ?>"><?php echo e($info->subject.' ( '.$info->licence_type.' ) '); ?></option>
                     <?php endforeach; ?>
               </select>
            </div>
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1" class="col-sm-2 control-label">Exam Date</label>
            <div class="col-sm-4">
               <div class="input-group">
                  <div class="input-group-addon glyphicon glyphicon-calendar"></div>
                  <input name="exam_date" value="<?php echo e($details->exam_date); ?>"type='text' class="form-control dateExam" placeholder="DD/MM/YYYY"/>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1" class="col-sm-2 control-label">Start Time</label>
            <div class="col-sm-4">
               <div class="input-group">
                  <div class="input-group-addon glyphicon glyphicon-time"></div>
                  <input name="start_time" value="<?php echo e($details->start_time); ?>" type='text' class="form-control timeExam" placeholder=""/>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1" class="col-sm-2 control-label">End Time</label>
            <div class="col-sm-4">
               <div class="input-group">
                  <div class="input-group-addon glyphicon glyphicon-time"></div>
                  <input name="end_time" value="<?php echo e($details->end_time); ?>" type='text' class="form-control timeExam" placeholder=""/>
               </div>
            </div>
         </div>
         <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Total Question</label>
            <div class="col-sm-4">
               <input name="total_question" value="<?php echo e($details->total_question); ?>" type="number" min="0" set="1" name="" class="form-control"  placeholder="">
            </div>
         </div>
         <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Total Sit</label>
            <div class="col-sm-4">
               <input name="total_sit" value="<?php echo e($details->total_sit); ?>" type="number" min="0" set="1" name="" class="form-control"  placeholder="">
            </div>
         </div>
         <div class="form-group">
            <label for="exampleInputEmail1" class="col-sm-2 control-label">Note</label>
            <div class="col-sm-6">
               <textarea name="note" class="form-control" rows="3"><?php echo $details->note;?></textarea>
            </div>
         </div>
         <div class="form-group">
            <label class="control-label col-md-1"></label>
            <div class="text-right col-md-8">
               <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
                  <button type="reset" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
                  <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Save </button>
               </div>
            </div>
         </div>
     <?php echo Form::close(); ?>

   </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('core.layout.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>