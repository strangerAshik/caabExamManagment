<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8">
	<form>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Licence Type</label>
	    <select placeholder=""class="form-control">
		  <option>Select Licence Type..</option>
		  <option>PPL</option>
		  <option>CPL</option>
		  <option>ATPL</option>
		</select>
	  </div>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Subject</label>
	    <select placeholder=""class="form-control">
		  <option>Select Subject..</option>
		  <option>Option-1</option>
		  <option>Option-2</option>
		  <option>Option-3</option>
		</select>
	  </div>

	  <div class="form-group">
	    <label for="date">Date</label>
	    <input type="date" class="form-control" id="date" placeholder="DD/MM/YYYY">
	  </div>

	  <div class="form-group">
	    <label for="date">Duration</label>
	    <input type="time" class="form-control" id="time" placeholder="i.e-14:00">
	  </div>

	  <div class="form-group">
	    <label for="Note">Note</label>
	    <textarea class="form-control" rows="3"></textarea>
	  </div>
	
	  
	   <div class="form-group">
	        <label class="control-label col-md-4"></label>
	        <div class="text-right col-md-8">
	            <div id="button1idGroup" class="btn-group pull-right" role="group" aria-label="">
	                <button type="button" id="button1id" name="button1id" class="btn btn-default" aria-label="Cancel">Cancel</button>
	                <button type="submit" id="button2id" name="button2id" class="btn btn-success" aria-label="Cancel">Save Shedule</button>
	            </div>

	        </div>
	    </div>
	</form>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>