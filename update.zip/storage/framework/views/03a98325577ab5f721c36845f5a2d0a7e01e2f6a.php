<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-12">

                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <b>Exam Archive</b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Title</th>
                                            <th>Category</th>
                                            <th>Subject</th>
                                            <th>Start Date</th>
                                            <th>Total Sit</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $num=0;?>
                                    <?php foreach($upcamingExams as $info): ?>
                                      <tr>
                                        <td><?php echo e(++$num); ?></td>
                                        <td><?php echo e($info->title); ?></td>
                                        <td><?php echo e($info->licence_name); ?></td>
                                        <td><?php echo e($info->sub_name); ?></td>
                                        <td><?php echo e($info->exam_date); ?></td>
                                        <td class="center"><?php echo e($info->total_sit); ?></td>
                                        <td class="center"><a href="<?php echo e(url('examShedule/singleShedule/'.$info->id)); ?>">view</a></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
        
        </div>
        
    </div>
           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutAdminTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>