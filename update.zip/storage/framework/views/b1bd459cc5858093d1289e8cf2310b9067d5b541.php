<?php $__env->startSection('content'); ?>
    <div class="row"><!--Container row-->

        <div class="span8 contact"><!--Begin page content column-->

            <h2 class="title-bg"><?php echo e($about->title); ?></h2>
           
             <p><?php echo $about->content;?></p>


        </div> <!--End page content column-->

        <!-- Sidebar
        ================================================== --> 
        <div class="span4 sidebar page-sidebar"><!-- Begin sidebar column -->
            <h5 class="title-bg"><?php echo e($mission->title); ?></h5>
            <p>
                <?php echo $mission->content ;?>
            </p>
            <h5 class="title-bg"><?php echo e($vission->title); ?></h5>
            <p>
                <?php echo $vission->content ;?>
            </p>
        </div><!-- End sidebar column -->

    </div><!-- End container row -->


<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('front.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>