<?php $__env->startSection('content'); ?>
<style type="text/css">
    .formAddonWidth{width:100px!important;}
</style>
    <div class="row"><!--Container row-->

        <div class="span8 contact"><!--Begin page content column-->

            <h2 class="title-bg">Register</h2>
               <form class="form-horizontal" action='afterRegistration'>

                  <div class="control-group">
                    <label class="control-label" for="title">Title</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="text" id="title" placeholder="">
                    </div>
                  </div>

                 
                  <div class="control-group">
                    <label class="control-label" for="title">Full Name</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="text" id="title" placeholder="">
                    </div>
                  </div>
                
                  <div class="control-group">
                    <label class="control-label" for="title">Father Name</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="text" id="title" placeholder="">
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Mother Name</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="text" id="title" placeholder="">
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Date Of Birth</label>
                    <div class="controls">
                      <input class="input-xxlarge dateExam" type="date" id="title" pattern="\d{1,2}/\d{1,2}/\d{4}"  title="DD/MM/YYYY" placeholder="DD/MM/YYYY">
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Email</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="email" id="title" placeholder="" >
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Nationality</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="text" id="title" placeholder="">
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Passport No</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="text" id="title" placeholder="">
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Validity Date</label>
                    <div class="controls">
                      <input class="input-xxlarge dateExam" type="date"  placeholder="DD/MM/YYYY">
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Permanent Address</label>
                    <div class="controls">                     
                      <textarea class="input-xxlarge"></textarea>
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Mailing Address</label>
                    <div class="controls">
                        <textarea class="input-xxlarge"></textarea>
                    </div>
                  </div>

                  <div class="control-group">
                    <label class="control-label" for="title">Gender</label>
                    <div class="controls">
                      <select class="span5">
                        <option>Select Gender..</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>
                 


                  <div class="control-group">
                    <label class="control-label" for="title">Photo</label>
                    <div class="controls">
                    <img id="blah" alt="your image" width="100" height="100" />
                      <input class="input-xxlarge" type="file" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                  </div>


                  <div class="control-group">
                    <label class="control-label" for="title">Password</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="password" id="title" placeholder="" pattern=".{6,}" title="Six or more characters">
                    </div>
                  </div>
                  <div class="control-group">
                    <label class="control-label" for="title">Re-Type Password</label>
                    <div class="controls">
                      <input class="input-xxlarge" type="password" id="title" placeholder="" pattern=".{6,}" title="Six or more characters">
                    </div>
                  </div>
                


                 
                  <div class="control-group">
                    <div class="controls">                     
                      <button type="submit" class="btn btn-inverse">Register</button>
                    </div>
                  </div>
                </form>
           
           


        </div> <!--End page content column-->

        <!-- Sidebar
        ================================================== --> 
        <div class="span4 sidebar page-sidebar"><!-- Begin sidebar column -->
         <span>Registered ? Login <a href="#">Here</a></span>
            <h5 class="title-bg">Instruction</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla iaculis mattis lorem, quis gravida nunc iaculis ac. Proin tristique tellus in est vulputate luctus fermentum ipsum molestie. Vivamus tincidunt sem eu magna varius elementum. Maecenas felis tellus, fermentum vitae laoreet vitae, volutpat et urna.</p>
        </div><!-- End sidebar column -->

    </div><!-- End container row -->


<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('front.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>