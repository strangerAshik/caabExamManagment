<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('core.examine.personalInfo.professionalData', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('professionalData'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutExamine', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>