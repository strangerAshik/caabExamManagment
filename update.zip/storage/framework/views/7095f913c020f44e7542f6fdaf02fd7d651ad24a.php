<?php $__env->startSection('content'); ?>


<!--Question -->

<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
		<!-- To get result  -->
					  <?php $num=0;?><?php $totalQuestion=0;$corrAns=0;?>
                       <?php foreach($questions as $info): ?>
                       <!-- Given Ans -->
                        <?php $ans=App\ExaminerModel::previousResult(Auth::user()->id,$info->exam_id,$info->question_id) ;?>
                       <!-- Orginal Ans -->
                       	<?php $orgAns=App\ExaminerModel::orginalAns($info->question_id) ;?>
                       		<?php ++$totalQuestion;?>
	                        <?php if($orgAns==$ans): ?>
	                        <?php ++$corrAns; ?>
	                        <?php endif; ?>
                       	<?php endforeach; ?>
        <!--End fo get result  -->
                        <div class="panel-heading">
                            <b>Result | Total Question : <?php echo e($totalQuestion); ?> | Correct Answer : <?php echo e($corrAns); ?></b>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                       
                        <?php $num=0;?><?php $totalQuestion=0;$corrAns=0;?>
                       <?php foreach($questions as $info): ?>
                       <!-- Given Ans -->
                        <?php $ans=App\ExaminerModel::previousResult(Auth::user()->id,$info->exam_id,$info->question_id) ;?>
                       <!-- Orginal Ans -->
                       	<?php $orgAns=App\ExaminerModel::orginalAns($info->question_id) ;?>
						
                       <form action="#" >
                        <?php echo csrf_field(); ?>

                        <?php echo Form::hidden('exam_id',$info->exam_id,array('id'=>'exam_id')); ?>

                        <div class="col-md-6" >
                        
                        
	                        <label>
							<?php ++$totalQuestion;?>
	                        <?php if($orgAns==$ans): ?>
	                        <?php ++$corrAns; ?>
	                        <i class="fa fa-check-square-o text-success"  style="color: green"></i>
	                        
	                        <?php else: ?>	                        
	                        <i class="fa fa-times text-danger" style="color: red" ></i>
	                        <?php endif; ?>
	                        <?php echo e(++$num); ?>) <?php echo e($info->question); ?></label>  
	                        <div class="col-md-offset-1">
	                        	 <div class="radio">
								  <label>
								 
								    <input type="radio" disabled="" name="<?php echo e($info->question_id); ?>" id="hello" class="optionsRadio" value="1"
								     <?php if($ans==1) echo "checked='checked'";?> >
								    <?php echo e($info->option_1); ?>

								  </label>
								</div>
								
		                        <div class="radio">
								  <label>
								    <input type="radio" disabled="" name="<?php echo e($info->question_id); ?>" class="optionsRadio" value="2"
								     <?php if($ans==2) echo "checked='checked'";?> >
								     <?php echo e($info->option_2); ?>

								  </label>
								</div>
		                        <div class="radio">
								  <label>
								    <input type="radio" disabled="" name="<?php echo e($info->question_id); ?>" class="optionsRadio" value="3" 
								     <?php if($ans==3) echo "checked='checked'";?>>
								    <?php echo e($info->option_3); ?>

								  </label>
								</div>
								 <div class="radio">
								  <label>
								    <input type="radio" disabled="" name="<?php echo e($info->question_id); ?>" class="optionsRadio"  value="4"
								     <?php if($ans==4) echo "checked='checked'";?> >
								    <?php echo e($info->option_4); ?>

								  </label>
								</div>
	                        </div>
                        </div>
                        </form>
                       <?php endforeach; ?>
                     
    				<?php App\ExaminerModel::saveResult($examId,$totalQuestion,$corrAns);?>
	                       

	                       
                        </div>
		
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('core.layout.layoutExamine', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>