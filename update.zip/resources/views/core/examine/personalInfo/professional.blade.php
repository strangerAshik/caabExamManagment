@extends('core.layout.layoutExamine')
@section('content')
  @include('core.examine.personalInfo.professionalData')
  @yield('professionalData')
@stop