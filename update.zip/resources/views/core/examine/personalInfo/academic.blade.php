@extends('core.layout.layoutExamine')
@section('content')
 @include('core.examine.personalInfo.academicData')
 @yield('academicData')
@stop