@extends('core.layout.layoutAdminTable')
@section('content')

@stop