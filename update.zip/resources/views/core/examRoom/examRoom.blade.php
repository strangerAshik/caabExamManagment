@extends('core.layout.layoutExamine')
@section('content')

@stop