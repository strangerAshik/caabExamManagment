@extends('front.layout.layout')
@section('content')
    <div class="row"><!--Container row-->

        <div class="span12 contact"><!--Begin page content column-->

            <h2 class="title-bg">Thanks For Registration</h2>
            <p>Your Access Privilege will activated after approval. An email will send to you informing your approval information after review your information</p>

        

        </div> <!--End page content column-->


    </div><!-- End container row -->


@stop